# GrassMan
Projet d'info première année CPP Valence, par Marine Prunel, Eric Durand, Nicolas Strekowski et Julie Andre.

# Trello:
https://trello.com/invite/b/Uy4KVh03/ATTIb68c9ba514a800effa7acfc58a34aa70FA566FE7/grassman

# Lancer GrassMan:

Verifiez que vous ayez bien python 3.12 + installé, et pip dans le PATH.

Double cliquez sur le fichier "SetupModulesAndLaunch", puis votre ordinateur téléchargera les bibliotheques requises au fonctionnement de l'appli et puis la lancera.

Après cette étape, il faudra cliquer sur "GrassMan" pour lancer l'application.

Note: Il ne faut pas fermer la console lors de l'execution, même après la fin des téléchargements, car comme python tourne sur la console, l'appli se fermera aussi.